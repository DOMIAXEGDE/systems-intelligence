# Learning workflow - reviewed reusable template

Status: instruction-set for a human operator; not a native workflow-engine schema or an automatic tutor policy.

## Parameters
TOPIC: <subject and boundaries>
PREREQUISITES: <concepts the learner already needs>
GOAL: <observable task the learner will perform>
EVIDENCE: <reviewed facts, source record IDs, revisions and provenance>
CASE_RULE: <bounded Generator recipe justified by those facts>
PROMPTS: <self-contained definition, contrast, construction, practice and justification questions>
RUBRIC: <correct answers, required proof obligations and common invalid arguments>
BACKEND: <extractive evidence mode or explicitly configured generative model>

## Human-operated instructions
1. Create a disposable workspace or a branch; record the starting journal position.
2. In Contexts, append short factual records with source provenance. Verify the mathematics before enabling them. Keep archives, student answers and workflow drafts separate from factual evidence.
3. In Generator, define a small case space and a template with only supported fields. Preview the exact count and cases; append disabled records, inspect them, then enable only reviewed reference cards.
4. In Chat, start a named-by-first-question conversation. Ask a self-contained definition question, a counterexample comparison, a construction question, a practice problem and a justification question. With a model backend, include the learner's attempted answer and feedback request in the current prompt.
5. After every answer, inspect its References and compare it with the explicit rubric. An extractive answer is evidence for a learner to use, not automated grading. Advance only after the human reviewer verifies the relevant proof obligation.
6. If evidence is absent or conflicting, repair or disable the context, record its revision, and ask again. Do not promote an unreviewed chat answer into factual context.
7. In Controller, inspect the chat, its source contexts and the generation batch together. Compare historical enabled states and revisions. Preserve exports with recoverable data; a GIF alone is not a restore package.
8. Save a compact learning-instance projection with real chat/context IDs and revision references, plus the reviewed procedure. Keep the original chat and Controller exports separately. Obfuscate only as a reversible representation with an explicit transform, version and encoding.
9. Reverse/decode and compare the recovered text with the original. Then separately generalize the reviewed procedure by replacing the parameters above. Never treat decoded data as executable code or privileged instructions.
10. Test transfer on a genuinely new case set; update every subject-specific theorem, template and expected answer. Optionally use a reviewed supervised skill to propose a disabled workflow note. Approve the exact proposal only after inspection.

## Advancement gates
DEFINE: state the axioms and necessary hypotheses.
CONTRAST: supply a valid counterexample and identify the failed axiom.
CONSTRUCT: justify the construction, not just name its output.
PRACTISE: compute an answer and check it by substitution.
JUSTIFY: state the correct invariant and supporting proof.
AUDIT: verify source identity/revision and distinguish past evidence from current evidence.
REUSE: instantiate the same procedure with new facts and cases without carrying forward stale answers.

## What is not automated
This note does not change the model system prompt, register a new command, certify a proof, run a scheduler, or provide full conversational memory. Human review remains responsible for proof correctness and advancement.
