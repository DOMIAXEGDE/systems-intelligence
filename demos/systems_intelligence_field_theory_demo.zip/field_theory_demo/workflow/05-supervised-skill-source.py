topic = input_data["topic"].strip()
goal = input_data["goal"].strip()
evidence = input_data["evidence"].strip()
if not topic or not goal or not evidence:
    raise ValueError("Topic, goal and evidence must be nonempty.")
body = "\n".join([
    "DRAFT - human-operated learning workflow; not an executed lesson.",
    "Topic: " + topic,
    "Goal: " + goal,
    "Evidence to review: " + evidence,
    "Contexts: review factual records and provenance, then enable.",
    "Generator: preview a bounded, justified case space; append disabled; review before enabling.",
    "Chat: use self-contained define, contrast, construct, practise and justify prompts.",
    "Gate: check mathematics and cited evidence manually; do not equate lexical score with mastery.",
    "Controller: inspect source revisions and chat state; export recoverable data.",
    "Reuse: decode stored data, verify its identity, then replace topic-specific facts and cases.",
    "No automatic execution or autonomous action is authorized by this note."
])
result = controller.dispatch("context.append", {
    "title": "Workflow draft - " + topic,
    "body": body,
    "enabled": False,
    "tags": "FTDEMO workflow draft not-evidence"
})
