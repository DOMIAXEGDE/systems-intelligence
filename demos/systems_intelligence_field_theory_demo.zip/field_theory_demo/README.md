# systems-intelligence: field-theory learning-chat demo

## Purpose and boundaries

This is a human-executed HTTP UI walkthrough for the current `systems_intelligence/` application and its shared `PandR_v3/` package in the uploaded `doc.md` source snapshot. Do not use the older `misc/frame_lm/` copy as the implementation target. The source describes the Controller workspace as version 0.4, although some individual package/doc version strings lag behind it. [P1]

The subject is **algebraic field theory**: field axioms, prime fields, polynomial quotient fields and extension degree. “Formal” means definitions, explicit hypotheses and mathematical justifications here; this demonstration does not claim Lean/Coq-style machine-checked proofs.

The demo uses “obfuscation” in two precise senses: package the teaching method inside a concrete learning instance, then reversibly encode that instance. Decoding restores the same instance. Extracting a reusable instruction-set is a **separate, human-reviewed abstraction step**, not a hidden ability of the codec.

**Execution status:** the application and your browser UI were not operated to produce this kit. `checks/validation.json` records independent checks of the supplied data, arithmetic, encoding round trips and optional skill source. The UI checks below are for you to perform. Expected answers are not fabricated runtime logs.

## What each component does

| Component | Role in this demo | Important limit |
|---|---|---|
| Context Studio / Contexts | Curated factual records, editing, retrieval enable/disable and provenance | A saved workflow note is reference data, not a new system prompt. |
| Generator | Enumerates a small case space; templates records; reverses text | It neither invents mathematical lessons nor computes proofs. |
| Chat | Evidence-grounded questions and saved responses | The default backend extracts sentences, rather than acting as a generative tutor. |
| Controller | Inspects entities, revisions, events and historical state; exports/branches; dispatches reviewed actions | Plots and lexical scores do not certify learning or mathematical truth. |
| P&R companion | The registered `pandr.codec` reversible text/rank conversion | Encoding is not encryption or compression. |
| Optional reviewed skill | Proposes one disabled reusable-workflow note | It is trusted local Python, not an OS sandbox or an autonomous curriculum engine. |

These roles and limits come from the supplied app guides and implementation. [P2–P8]

## 1. Open the HTTP workspace

For a first build on Windows, open PowerShell at the repository root:

```powershell
.\systems_intelligence\build.ps1
.\systems_intelligence\start-context-studio.cmd
```

The workspace normally opens at:

```text
http://127.0.0.1:8765
```

An already installed environment can start it from `systems_intelligence/` with:

```powershell
python -m framelm studio
```

Use the same Python environment used by the build. Python 3.11 or newer is the current repository requirement. Keep the terminal/server open during the exercise. Apart from starting or switching a server, the main exercise uses UI forms, not curl, DevTools or direct database writes. [P1, P2]

Use a disposable/test workspace when possible. Otherwise, all new material has `FTDEMO` tags; modify only the demo records and leave pre-existing sources alone. Exports are records of the exercise, not substitutes for a complete database backup. The configured SQLite database is authoritative state, not disposable cache. Stop running processes before making a full state-directory backup. [P2, P3]

### Choose the learning mode

The guaranteed no-model route is the default **extractive** backend. You do the mathematical work; Chat retrieves supporting excerpts and preserves your questions and responses. It may repeat excerpts and does not reliably follow a request to ask a Socratic question or grade a proof.

For generated feedback, use the project's configured Ollama route only after its model server/model are installed and the placeholder model name in `configs/served.json` is replaced. Launch using:

```powershell
python -m framelm --config configs/served.json studio
```

Use the same context database when changing backends if you want to retain the lesson state. The UI identifies the configured backend; each response identifies the selected backend/fallback. A ranker can select an extractive fallback even with a model configured. Requiring generated candidates uses `include_extractive_fallback: false`, with the trade-off that failures or citation problems remain errors/unresolved results. This is not necessary for the core demo. [P3]

## 2. Create the factual learning contexts

In **Contexts → + Append context**, create these four records. Copy the full matching `.txt` file into **Context text**, use the title below, add tags `FTDEMO mathematics field-theory verified-demo`, and leave **Enabled for retrieval** checked.

| Title | Body file | Learning function |
|---|---|---|
| FT01 - Field axioms and cancellation | `contexts/FT01.txt` | Define a field; justify nonzero cancellation. |
| FT02 - Prime fields and modular counterexamples | `contexts/FT02.txt` | Compare F5 with Z/6Z and Z/4Z. |
| FT03 - Irreducibility and quotient construction | `contexts/FT03.txt` | Explain why the polynomial quotient is a field. |
| FT04 - Constructing F4 and its extension degree | `contexts/FT04.txt` | Compute in F4 and distinguish degree from size. |

Click **Save context** after each. Saving updates retrieval immediately. You do not need a full reindex after every edit. Open **Generation & source details** to note each real record ID and revision. Labels such as FT04 are human labels; they are not the UUID or the per-reply citation identifier. [P2, P4]

The context cards are authored teaching notes with source provenance, not copied textbook passages. Their underlying field/extension facts are supported by the Stacks Project references in `SOURCES.md`; their small computations and proof steps are written out in the cards. [M1–M5]

**Alternative using the Controller:** select `context.append` in **Action & P&R workbench**, paste one `controller/append-FT0N.json` file as **Command JSON**, and choose **Execute command**. Use either the Contexts route or this route for a card, not both. The dropdown selects the command; the textarea takes its payload only. [P5]

Do not put this entire demo kit into the application's contexts folder: it also contains archives, expected outputs and workflow instructions that should not all become factual retrieval sources. **Import new files** adopts `.txt`/`.md` files from the configured server-side folder; it is not a browser upload/restore control for this zip. [P2]

## 3. Generate meaningful learning cases

Open **Generator → Load recipe** and select `recipes/01-f4-cards.json`.

The meaningful mathematical rule is: every element of F4 has a unique form `a+b*alpha`, with `a,b` in F2. Binary coefficient codes therefore give exactly four cases. Generator enumerates the codes; the theorem justifying the interpretation is in FT03/FT04. [M3, M4]

Check these settings after loading:

| Field | Value |
|---|---|
| Generation flow | Custom Cartesian |
| Input text / custom alphabet | `01` |
| Width / repeat count | `2` |
| Start | `0` |
| Limit | `4` |
| Title template | `{object_name} / {payload}` |
| Prefix and suffix | Both empty |
| Enabled | Unchecked initially |

The complete recipe also fixes all remaining fields, so previous form values cannot accidentally leak into it.

Click **Preview generation**. Expect **4** planned records with payloads **00, 01, 10, 11**. Then click **Append generated contexts**. For the first run with that recipe identity, expect **4 appended**. In Contexts, inspect each generated body and its provenance, then enable those four reviewed cards. [P2, P6]

The left digit means `a`; the right digit means `b`. Therefore the cases are:

| Code | Element | Inverse when nonzero |
|---|---|---|
| 00 | 0 | None |
| 01 | alpha | alpha+1 |
| 10 | 1 | 1 |
| 11 | 1+alpha | alpha |

These answers follow from FT04; the template is deliberately not pretending to calculate them. [M3, M4]

Re-run the unchanged recipe as an idempotency check. Expect **0 appended, 4 skipped**, including preservation of your reviewed enabled states. Changing a content-bearing field creates a different recipe identity; changing only a batch window or enabled flag does not replace existing records. Do not use a repeated generation request as an edit operation. [P2, P6]

**Pass:** four distinct reviewed cases, correct coefficient interpretation, no invented computed answer, and reproducible batch identity.

## 4. Run the learning Chat

Open **Chat → + New conversation**. A first prompt containing `FTDEMO` makes the conversation recognizable; there is no separate rename step required. Send the prompts in `PROMPTS.md` one at a time. For every response, open **References**, read the actual evidence and compare it with the mathematical checks below. A supporting citation matters more than fluent wording. [P3, P4]

| Stage | Self-contained prompt | Human-reviewed success criterion |
|---|---|---|
| Define | `FTDEMO FT01: What are the field axioms, and why does cancellation require a nonzero factor?` | Nonzero multiplicative inverse and the cancellation hypothesis are stated. |
| Contrast | `FT02: Compare the inverse of 2 in F5 with the zero-divisor obstruction in Z/6Z.` | In F5, 2*3=1; in Z/6Z the nonzero 2 and 3 multiply to zero. |
| Construct | `FT03: Why is t^2+t+1 irreducible over F2, and why does its quotient define a field?` | Evaluate at 0 and 1; use the quadratic no-root test and the irreducible-quotient result. |
| Practise | `FT04: What is the inverse of alpha in F4? Show the product reducing to 1.` | alpha*(alpha+1)=alpha^2+alpha=(alpha+1)+alpha=1. |
| Justify | `FT04: Compare [F4:F2], the number of elements of F4, and the ring Z/4Z.` | Degree 2, size 4; F4 is not Z/4Z. |

The expected mathematics follows from the definitions, quotient construction and explicit computations in the cards. [M1–M5]

In extractive mode, do not expect every requested multi-step proof to appear in one response. Read the cited source via **Open context**, do the proof yourself and narrow the next question to a missing step. Save a reviewed learning note separately rather than counting sentence retrieval as mastery.

### A productive correction turn with a model backend

```text
FT04 F4 learning check. My attempted answer is: alpha^(-1)=alpha because alpha^2=1.
Use the retrieved field-theory evidence to assess this claim. Identify the first invalid equality,
give one hint before the correction, and cite the supporting records. Do not certify mastery.
```

A correct correction rejects `alpha^2=1` and uses `alpha^2=alpha+1`. This is a proposed generative teaching prompt, not a promised response from extractive mode.

**Repeat important instructions in the current turn.** The source implements lightweight last-topic carryover, not full-history prompting. Include the student's current attempt and the current rubric in the same message; do not assume the first instruction “be my tutor” persists as a full model policy. Chat answers also do not automatically become contexts. [P3, P4]

### Evidence-change experiment

After the irreducibility question, disable **only FT03**, then repeat that exact question. Open the new reply's References. FT03 must be absent from current retrieval; the old response must still preserve its old reference snapshot. Other enabled records may supply overlapping evidence, so an insufficient-context status is **not** guaranteed. Re-enable FT03 before continuing. Record the actual revision changes. [P2–P4]

Finally, use **Export chat** and retain the JSON. It exports the displayed conversation, subject to the UI's latest-100-turn limit; it is not a universal full-history restore package. Keep broader Controller exports/full backups separately. [P3]

## 5. Use Controller to make the learning process inspectable

In Controller, select the saved chat, FT03/FT04 and the F4 generation batch. **Inspect** next to a context and **Inspect chat in Controller** next to a conversation provide shortcuts. Clear narrow kind/text filters when needed to select different entity types. Record the real identifiers and current journal position. [P7]

Inspect **Machine-readable state**, using these views for different questions:

| View | What to inspect | What not to conclude |
|---|---|---|
| revision / enabled | FT03 changes across disable and re-enable | An old answer was retroactively rewritten. |
| generation | Bounded batch count and committed outcome | Every provisional event became a saved context. |
| chat_activity | Recorded turns | Turn count is mastery. |
| retrieval / candidates | Evidence and ranking diagnostics | A lexical score is a calibrated confidence or truth probability. |
| bytes | Recoverable representation of recorded state | Plot pixels alone restore the state. |

Choose journal positions before and after the FT03 change and use **Inspect position**, or the replay controls. Historical replay displays recorded states; it does not rerun the model or replay Python side effects. Return to the current position before continuing work. [P7]

Use **Export selection JSON**, checking **Include recoverable byte-function models** for that export. For the demo interval, use **Export data** or **Export GIF + data** and keep the machine-readable companion/bundle. A GIF alone is a visualisation, not an exact restore mechanism. [P7, P8]

### Optional isolated branch

Record the desired journal position, supply a new absolute **Branch destination**, and select **Branch selected position**. The destination must not already exist. A branch captures the workspace at that position, not only the currently checked display subset. Skills are disabled and autonomy is paused in the branch. It does not switch the current browser automatically. [P7, P8]

The generated configuration is `<destination>/configs/controller.json`. Start a second server using the same installed environment, for example:

```powershell
python -m framelm --config "C:/si-field-demo-branch/configs/controller.json" studio --port 8766
```

Substitute the actual destination you chose. Open the second server's URL. Do not assume a GIF or selection JSON has a one-click import control. [P7, P8]

## 6. Package and obfuscate a learning-chat instance

### 6A. First perform the reproducible worked example

`workflow/02-learning-capsule.txt` is a one-line, ASCII JSON object containing the topic, goal, evidence labels, five short learner/reviewed-answer exchanges, workflow operations, a review gate and reuse instructions. Its `origin` explicitly identifies it as an **authored worked example, not a live chat export**. It uses a demo-defined schema, not a built-in import format.

The exact sample is **1,442 UTF-8 bytes**, below Generator's **4,096-byte per-text-field limit**. [P6]

Open Generator, load `recipes/02-obfuscate-example.json`, and verify:

| Field | Value |
|---|---|
| Flow | Reverse text |
| Input | Exact sample capsule |
| Start / limit | 0 / 1 |
| Prefix / suffix | Empty / empty |
| Body template | `{value}` |
| Title | Generated from `FTDEMO capsule reversed` |
| Enabled | Unchecked |

Choose **Preview generation → Append generated contexts**. Open the new record in Contexts. Its **Context text** should be the capsule reversed character by character. Copy only that body, not its title, the displayed provenance, or a JSON-escaped enclosing export object. [P6]

The supplied exact comparison is `checks/example-reversed.txt`.

**This is not secrecy.** In this implementation the generated record's provenance retains the recipe, including its original input; Controller history can retain the input and outputs too. Disabling a record excludes it from future retrieval but does not erase it or revoke access to it. Do not use this technique to protect sensitive learning data. [P2, P6]

### 6B. Recover by applying the inverse transform

Stay in Generator and load `recipes/03-recover-example.json`. Replace its **Input text** with the reversed body you actually copied, so you test the real output rather than simply trusting the supplied comparison file. Keep flow **Reverse text**, prefix/suffix empty, body `{value}`, start 0, limit 1 and **Enabled** unchecked. Use the distinct object name `FTDEMO capsule recovered`.

Preview and append. Open the recovered record. Its body must match `workflow/02-learning-capsule.txt` exactly. For reversal, `R(R(s))=s`; there is no inference or language-model step in the decode. Compare the contents, not just the fact that the result looks like readable JSON. [P6]

### 6C. Repeat with your actual learning session

Open `workflow/03-your-run-capsule-template.json` in a text editor. Insert the real chat ID, selected exact prompt/response, source record ID/revision, journal position and your actual review. Retain a clear statement that this is a **projection**, not the complete transcript. Replace the Generator input with this reviewed capsule, staying below 4,096 UTF-8 bytes, and repeat 6A–6B with new object names.

The transformation is lossless for the text you actually encode. It does not turn a summary into a lossless archive of omitted turns, timestamps or references. For a small raw chat export below the limit, the entire export text can be the input; for larger conversations keep the original export and use a compact projection for this UI demo. Do not silently truncate data or claim that a projection restores the whole conversation.

### 6D. Demonstrate the P&R companion codec

In **Controller → Action & P&R workbench**, choose **`pandr.codec`**. Paste this payload and execute:

```json
{"action":"encode","alphabet":"ab","value":"ab"}
```

The mathematical shortlex result is `{"value":"4"}`. Change only the action/value as follows:

```json
{"action":"decode","alphabet":"ab","value":"4"}
```

Expect `{"value":"ab"}`. The command is selected separately; do not paste an API wrapper into the payload box. [P5, P9]

Next paste `controller/codec-encode-example.json`, still with `pandr.codec` selected. That file contains the **whole worked-example capsule** and its explicit ordered printable-ASCII alphabet. The result should contain a **2,852-digit decimal string**. Compare it with `checks/codec-expected-result.json`.

For the actual round-trip, start from `controller/codec-decode-example.json`, replace `value` with the decimal string you received, retaining its quotation marks and the exact alphabet, and execute. The returned value must be the original capsule. The JSON UI may show escaped inner quotation marks; compare the decoded string content, not the pretty-printed outer JSON formatting.

Keep ordinals as **strings**: a JavaScript number cannot safely represent this value. The character codec is bounded to 4,096 input symbols and depends on the identical ordered alphabet. Newlines/Unicode require a suitable alphabet or escaped one-line ASCII JSON; the supplied sample avoids that issue. The digit string is larger than this input, so do not call it compression. This is an alternative encoding of the sample, not a key-based cipher. [P9]

## 7. De-obfuscate the teaching method into a reusable instruction-set

Open the recovered capsule. Identify these concrete-to-general correspondences:

| Recovered field-theory instance | General learning-workflow parameter |
|---|---|
| Field axioms, F5 and F4 | TOPIC plus selected example/counterexample set |
| Groups, modular arithmetic, polynomial division | PREREQUISITES |
| Construct F4 and justify an inverse | Observable GOAL |
| FT01–FT04 and their actual revisions | Curated EVIDENCE |
| Two binary coefficients | Bounded CASE_RULE / Generator recipe |
| Define, contrast, construct, practise, justify | PROMPT_SEQUENCE |
| Product equals 1; irreducibility argument; degree versus size | Explicit RUBRIC / proof obligations |
| Source review, historical inspection and exports | REVIEW_AND_AUDIT_GATES |

The codec did not invent these parameters. You are extracting a method explicitly represented by the recovered instance and reviewing how far it generalizes.

Read `workflow/04-reusable-workflow.md`. Fill the parameters with actual records and a new learning goal. Save it as a new **disabled** Context record titled `FTDEMO - Reusable learning workflow`, or use `controller/append-workflow.json` with `context.append` to save the provided template. It is a human-readable instruction-set and audit note, not a built-in workflow scheduler. [P4, P5]

The resulting operator sequence is:

**Curate facts → preview bounded cases → review/enable → ask → check proof obligations → inspect changes → export → encode/recover → generalize → test transfer.**

For the default extractive backend, the human performs the synthesis and grading. With a model backend, a new self-contained request can ask it to draft an abstraction from explicitly supplied reviewed data, but its draft still requires review. Do not rely on a first-turn instruction persisting or let encoded text become a privileged system instruction. [P3, P4]

## 8. Prove reuse by transferring from F4 to F8

Append and enable the optional `contexts/FT05-optional-transfer.txt` as **FT05 - Transfer to F8**. It provides the new proof and arithmetic; old F4 facts are not silently reused as F8 facts.

The new construction is `F8=F2[t]/(t^3+t+1)`. The cubic evaluates to 1 at both elements of F2, so it has no root and is irreducible. With `beta` the residue of t, `beta^3=beta+1` and `beta*(beta^2+1)=1`. Unique representatives are `a+b*beta+c*beta^2`, giving eight elements and extension degree 3. These are explicit applications of the earlier quotient-field and degree results. [M3–M5]

Load `recipes/04-f8-transfer.json`, preview **eight** coefficient codes `000` through `111`, append disabled, inspect and enable reviewed cards. The file changes the body, object name, rule names, width and limit; merely changing width while retaining F4's two-coefficient prose would be an error.

Start a new Chat and ask:

```text
FT05: Why is t^3+t+1 irreducible over F2, and what are the size and extension degree of its quotient field?
```

Then:

```text
FT05: Verify that beta^2+1 is the inverse of beta using beta^3=beta+1.
```

Use the same evidence/rubric/Controller/export gates. The successful reusable object is the procedure, not a memorized F4 answer.

## 9. Optional: turn the instruction-set into a supervised skill action

This optional step demonstrates the project's approved-skill machinery without granting autonomy. Review the exact Python in `workflow/05-supervised-skill-source.py`. It only formats supplied topic/goal/evidence text and requests one disabled `context.append`; it does not run a lesson, grade a proof, decode untrusted code or grant permissions.

In **Controller → Scripts · Skills · Plugins → Draft a plugin**, paste `workflow/05-supervised-skill-manifest.json` and choose **Save draft**. Open **Review source, schemas and declarations**, check that the only declared capability is `context.append` and there are no triggers, then choose **Approve this version**. [P10]

Paste `workflow/06-skill-input.json` into the skill's input box, replacing its evidence note with actual reviewed context IDs/revisions. Click **Run**. In **Supervised action proposals**, inspect the proposed target title/body and `enabled:false`, then choose **Approve this action**. Confirm the resulting disabled workflow record in Contexts. [P10]

Do not click **Configure grant** for this exercise. Source approval and action approval are separate; activation alone does not authorize autonomous mutations. The scope `context:*` is a broad declaration needed for creating a new context, not a security guarantee for the host machine. Trusted Python still runs with host-user access. Disable the demo skill after the exercise. [P10]

## Acceptance checks and common failures

| Check | Pass condition |
|---|---|
| Factual foundation | Four short reviewed factual contexts; distinct real IDs/revisions recorded. |
| Generation | 00,01,10,11; four initial records; unchanged repeat skips existing records. |
| Learning | Correct nonzero inverse hypothesis, counterexample, quotient construction, inverse product and extension degree. |
| Grounding | References support claims; disabling FT03 removes it from later references but not earlier snapshots. |
| Audit | Relevant entities and before/after journal positions inspected; machine-readable exports retained. |
| Obfuscation | Reverse output differs; two reversals recover the exact supplied text; archive remains disabled. |
| P&R codec | ab↔4 calibration and whole-example capsule round-trip match. |
| Generalization | A reviewed parameterized workflow is saved; no invented native workflow engine. |
| Transfer | Eight F8 cases use new facts, correct inverse and degree 3. |
| Optional skill | One reviewed disabled context is proposed and approved; no autonomous grant. |

**Recipe loaded but append is disabled:** click Preview again. Any edit invalidates the preview. [P6]

**Unexpected extra contexts or skipped cases:** inspect recipe identity and existing records. Changing content can create a new identity; unchanged generation preserves existing edits and enabled states. [P6]

**References are irrelevant or the answer is incomplete:** narrow the question, inspect the evidence and add/revise a genuinely missing source. A retrieval score or “resolved” status is not proof of correctness. [P3, P4]

**A proof-feedback prompt only returns excerpts:** this is expected in extractive mode. Use the human rubric or explicitly configured generative backend. [P3]

**The recovered text differs:** remove prefix/suffix; ensure body template is `{value}`; use only the original body, not title/provenance/JSON export wrappers; check copy/paste changes and encoding limits. [P6]

**A codec rejects the text:** ensure every character belongs to the exact alphabet and stay within its bounds. Never paste a large ordinal as a JSON number. [P9]

**A save or proposal is stale:** reload the current revision and review again. Do not bypass revision checks. [P2, P10]

## Files in this kit

`contexts/` contains the four main facts and optional F8 transfer fact.

`recipes/` contains complete loadable Generator recipes, including all fields to avoid stale form settings.

`controller/` contains payloads for the command selected in the Controller dropdown; filenames identify their purpose.

`workflow/` contains the compact authored example, your-run projection template, reusable instruction-set and optional supervised skill.

`checks/` contains expected encodings and the independently generated validation report. `SOURCES.md` maps implementation claims and mathematical foundations to their provenance. `PROMPTS.md` provides copyable chat prompts and a review log.
