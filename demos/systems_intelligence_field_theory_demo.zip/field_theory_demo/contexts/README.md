# Context cards

In Contexts, use **+ Append context**. Copy each title below and the complete matching `.txt` body. Tags: `FTDEMO mathematics field-theory verified-demo`. Enable FT01-FT04. These are authored teaching notes, not verbatim quotations or machine-checked proofs.

- `01`: FT01 - Field axioms and cancellation
- `02`: FT02 - Prime fields and modular counterexamples
- `03`: FT03 - Irreducibility and quotient construction
- `04`: FT04 - Constructing F4 and its extension degree

The `controller/append-FT*.json` files are alternative payloads for `context.append`; do not use both routes for the same card. Do not put this entire kit into the application contexts folder: the source notes, expected answers and workflow drafts have different intended retrieval states.
