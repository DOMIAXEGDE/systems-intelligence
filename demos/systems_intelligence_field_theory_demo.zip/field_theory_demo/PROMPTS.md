# Chat prompts and review log

Use one prompt per turn in a new conversation. The baseline retrieves evidence; a human checks the proof. With a model backend, include your attempted answer and requested feedback behaviour in the current message.

## Definition
```text
FTDEMO FT01: What are the field axioms, and why does cancellation require a nonzero factor?
```

## Contrast
```text
FT02: Compare the inverse of 2 in F5 with the zero-divisor obstruction in Z/6Z.
```

## Construction
```text
FT03: Why is t^2+t+1 irreducible over F2, and why does its quotient define a field?
```

## Practice
```text
FT04: What is the inverse of alpha in F4? Show the product reducing to 1.
```

## Justification
```text
FT04: Compare [F4:F2], the number of elements of F4, and the ring Z/4Z.
```

## Optional generated feedback
```text
FT04 F4 learning check. My attempted answer is: alpha^(-1)=alpha because alpha^2=1.
Use the retrieved field-theory evidence to assess this claim. Identify the first invalid equality,
give one hint before the correction, and cite the supporting records. Do not certify mastery.
```

## Self-contained correction follow-up
```text
FT04 F4 learning check. My corrected argument is:
alpha*(alpha+1)=alpha^2+alpha=(alpha+1)+alpha=1, since alpha+alpha=0.
Check each equality against the retrieved evidence. State which defining relation and characteristic I used.
```

## Transfer
```text
FT05: Why is t^3+t+1 irreducible over F2, and what are the size and extension degree of its quotient field?
```
```text
FT05: Verify that beta^2+1 is the inverse of beta using beta^3=beta+1.
```

## Human review log (not an app-import schema)

Chat ID:
Backend actually selected:
Starting and ending journal positions:
Context IDs and revisions:
Generator batch ID:

For each stage record the exact prompt, selected reply, references, supporting proof obligation, your verdict, and any correction. Do not fill “pass” merely because the UI says resolved. Keep this log disabled when storing it in Contexts unless deliberately using it as reviewed reference data for a meta-analysis task.
