# Source map and verification scope

## Project implementation source

All P-references below identify files inside the user's uploaded `doc.md` source bundle (snapshot supplied 13 September 2026). They are not claims that a remote repository or user's live server was executed. The current `systems_intelligence/` package and its shared `PandR_v3/` runtime take precedence over the archived `misc/frame_lm/` duplicate and stale blueprint-only wording in older guides.

**[P1]** Root `README.md`; `systems_intelligence/README.md`; `systems_intelligence/build.ps1`; `systems_intelligence/start-context-studio.cmd`: current package layout, Python 3.11+, build and startup.

**[P2]** `systems_intelligence/CONTEXT_STUDIO.md`; `systems_intelligence/framelm/context_store.py`; `systems_intelligence/framelm/studio_web/app.js`: Contexts append/edit/toggle, managed-state persistence, import/export, source provenance, retrieval changes and generation identity. The current root's dependency requirement overrides older guide text about Python 3.10/no dependencies.

**[P3]** `systems_intelligence/CHAT.md`; `systems_intelligence/framelm/chat.py`: backend modes, selected fallback, current evidence, persistent turns, limited topic carryover, latest-100 UI limit, export and no automatic answer-to-context promotion.

**[P4]** `systems_intelligence/framelm/core.py`: frame/context resolution, lexical retrieval and candidate ranking, extractive sentence selection, model messages, explicit instruction to treat contexts as reference data rather than instructions.

**[P5]** `systems_intelligence/framelm/controller/runtime.py`, `_register_defaults` and `_codec`; `systems_intelligence/framelm/studio_web/controller.js`: registered commands, payload contracts, dropdown dispatch and `pandr.codec` encode/decode.

**[P6]** `systems_intelligence/framelm/generator.py`, `Recipe.from_dict`, `plan`, `signature`, `payload`, `records`, `preview`; `systems_intelligence/framelm/studio_web/app.js`: 4,096 UTF-8 bytes per text field, numeric-string recipe fields, bounded enumeration, simple template keys, reverse via `input_value[::-1]`, recipe-bearing provenance, preview invalidation and load/save behaviour.

**[P7]** `systems_intelligence/CONTROLLER.md`; `systems_intelligence/framelm/studio_web/index.html`; `systems_intelligence/framelm/studio_web/controller.js`: HTTP UI names, entity selection, historical inspection, views, export and skill controls.

**[P8]** `systems_intelligence/framelm/controller/models.py`; `systems_intelligence/framelm/controller/visuals.py`; `systems_intelligence/framelm/controller/runtime.py`: typed byte-function models, replay data/bundles, historical branches including the whole workspace, branch generated configuration, paused/disabled skill state, no re-execution of side effects.

**[P9]** `PandR_v3/pandr/codecs.py`; `PandR_v3/tests/test_codecs.py`; `systems_intelligence/framelm/controller/runtime.py`, `_codec`: reversible ordered-alphabet shortlex ordinals and string limits. The independent small implementation used to validate this kit uses the mathematically equivalent recurrence `r <- base*r + index(character) + 1`, not the project's application runtime. The ab→4 calibration also appears among the project's codec tests/vectors.

**[P10]** `systems_intelligence/CONTROLLER.md`; `systems_intelligence/framelm/controller/skills.py`; `systems_intelligence/framelm/controller/sdk.py`; `systems_intelligence/examples/controller_plugin/plugin.json` and `summarize.py`; `systems_intelligence/framelm/studio_web/controller.js`: reviewed source digests, manual supervision, proposals, scope/capabilities, revocation and trusted-host-Python limitations. The optional kit skill is newly authored, not an existing installed skill.

## Mathematical foundations

The teaching cards are original concise explanations and worked calculations. They are not verbatim excerpts. The following primary mathematical references were consulted:

**[M1]** The Stacks Project, Fields, §9.2 “Basic definitions”, tag 09FC. Field/integral-domain definitions. https://stacks.math.columbia.edu/tag/09FC

**[M2]** The Stacks Project, Fields, §9.3 “Examples of fields”, tag 09FF. Prime fields and polynomial quotients by irreducible polynomials. https://stacks.math.columbia.edu/tag/09FF

**[M3]** The Stacks Project, Fields, §9.6 “Field extensions”, tag 09FT. Quotient-field extensions and generated extensions. https://stacks.math.columbia.edu/tag/09FT

**[M4]** The Stacks Project, Fields, §9.7 “Finite extensions”, tag 09G2. Extension degree and a polynomial-quotient basis. https://stacks.math.columbia.edu/tag/09G2

**[M5]** The Stacks Project, Fields, §9.18 “Finite fields”, tag 09HY. Prime-power cardinality from extension dimension. https://stacks.math.columbia.edu/tag/09HY

Finite arithmetic and the quadratic/cubic no-root arguments are explicit derivations in the cards. The inverse and enumeration checks in `checks/validation.json` were independently evaluated using integer/modular/polynomial arithmetic. This is not a formal proof-assistant verification of an arbitrary theorem.

## Scope of local validation

Checked: JSON parses; full recipes have supported field names; code lists enumerate 4 and 8 cases; F5 inverse products; every nonzero element in the supplied F4/F8 constructions has an inverse; the sample inverse identities; two reversals recover the exact capsule; the independent shortlex encoder/decoder round-trip; the optional skill compiles and, under a mock controller, requests one disabled `context.append`.

Not checked: your installed package version, actual browser interactions, live HTTP endpoints, a real Ollama model, database mutations, actual skill approval/execution on the project runtime, or UI display of these specific lesson files. Treat the runbook's UI outputs as acceptance tests to run, not already-observed results.
